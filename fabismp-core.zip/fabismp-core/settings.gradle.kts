rootProject.name = "fabismp-core"
